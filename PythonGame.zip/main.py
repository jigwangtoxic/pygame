import pygame
import sys
import random

def main_game():
    pygame.init()

    WIDTH, HEIGHT = 400, 600
    WHITE = (255, 255, 255)
    BLACK = (0, 0, 0)

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("FlyFly")

    bird_x = 100
    bird_y = 300
    bird_speed = 0

    gravity = 0.04

    flap_strength = -2

    obstacle_width = 50
    obstacle_speed = 1
    obstacle_spacing = 200
    obstacle_min_height = 50
    obstacle_max_height = HEIGHT - obstacle_spacing - obstacle_min_height
    score = 0

    game_started = False
    game_over = False

    bird_img = pygame.image.load('images/bird.png')
    background_img = pygame.image. load('images/background.png')

    font = pygame.font.Font(None, 36)
    text = font.render("Press 'Space' to start", True, BLACK)

    text_x = (WIDTH - text.get_width()) // 2
    text_y = (HEIGHT - text.get_height()) // 2 - 75

    obstacles = []

    def generate_obstacle():
        top_obstacle_height = random.randint(obstacle_min_height, obstacle_max_height)
        bottom_obstacle_height = HEIGHT - top_obstacle_height - obstacle_spacing
        top_obstacle = pygame.Rect(WIDTH, 0, obstacle_width, top_obstacle_height)
        bottom_obstacle = pygame.Rect(WIDTH, top_obstacle_height + obstacle_spacing, obstacle_width, bottom_obstacle_height)
        obstacles.append((top_obstacle, bottom_obstacle, False))

    # Main game loop
    while not game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if not game_started:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    game_started = True
                    bird_speed = flap_strength
                    obstacles = []
                    score = 0

            if game_started:
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    bird_speed = flap_strength

        if game_started:
            bird_speed += gravity
            bird_y += bird_speed

            obstacles_to_remove = []
            for top_obstacle, bottom_obstacle, scored in obstacles:
                top_obstacle.x -= obstacle_speed
                bottom_obstacle.x -= obstacle_speed

                if top_obstacle.right < bird_x and not scored:
                    score += 1
                    obstacles[obstacles.index((top_obstacle, bottom_obstacle, scored))] = (top_obstacle, bottom_obstacle, True)

                if top_obstacle.right < 0:
                    obstacles_to_remove.append((top_obstacle, bottom_obstacle, scored))

            for obstacle_pair in obstacles_to_remove:
                obstacles.remove(obstacle_pair)

            if not obstacles or WIDTH - obstacles[-1][0].x >= obstacle_spacing:
                generate_obstacle()

            for top_obstacle, bottom_obstacle, _ in obstacles:
                if bird_x + bird_img.get_width() > top_obstacle.left and bird_x < top_obstacle.right:
                    if bird_y < top_obstacle.bottom or bird_y + bird_img.get_height() > bottom_obstacle.top:
                        game_over = True
                        break

        screen.blit(background_img, (0, 0))
        screen.blit(bird_img, (bird_x, bird_y))
        for top_obstacle, bottom_obstacle, _ in obstacles:
            pygame.draw.rect(screen, BLACK, top_obstacle)
            pygame.draw.rect(screen, BLACK, bottom_obstacle)

        if not game_started:
            screen.blit(text, (text_x, text_y))

        score_text = font.render(f"Score: {score}", True, (0, 0, 255))
        screen.blit(score_text, (10, 10))
 
        pygame.display.update()

    pygame.quit()

while True:
    main_game()
